import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/EditServlet9")
public class EditServlet9 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		String feedback=request.getParameter("feedback");
		String message=request.getParameter("message");
		
		
		
		Emp8 e=new Emp8();
		
		e.setName(name);
		e.setEmail(email);
		e.setAddress(address);
		e.setFeedback(feedback);
		e.setMessage(message);
		
	
		
		int status=EmpDao8.update(e);
		if(status>0){
			response.sendRedirect("ViewServlet8");
		}else{
			out.println("Sorry! unable to update record");
		}
		
		out.close();
	}

}


