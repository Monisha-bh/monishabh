import java.util.*;
import java.sql.*;

public class EmpDao3 {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(Emp3 e){
		int status=0;
		try{
			Connection con=EmpDao3.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into menu(id,name,email,menu,no,message) values (crud.nextval,?,?,?,?,?)");
			ps.setString(1,e.getName());
			ps.setString(2,e.getEmail());
			ps.setString(3,e.getMenu());
			ps.setString(4,e.getNo());
			ps.setString(5,e.getMessage());
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int update(Emp3 e){
		int status=0;
		try{
			Connection con=EmpDao3.getConnection();
			PreparedStatement ps=con.prepareStatement("update menu set name=?,email=?,menu=?,no=?,message=? where id=?");
			ps.setString(1,e.getName());
			
			ps.setString(2,e.getEmail());
			ps.setString(3,e.getMenu());
			ps.setString(4,e.getNo());
			ps.setString(5,e.getMessage());
			ps.setInt(6,e.getId());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int delete(int id){
		int status=0;
		try{
			Connection con=EmpDao3.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from menu where id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	public static Emp3 getEmployeeById(int id){
		Emp3 e=new Emp3();
		
		try{
			Connection con=EmpDao3.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from menu where id=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				
				e.setEmail(rs.getString(3));
				e.setMenu(rs.getString(4));
				e.setNo(rs.getString(5));
				e.setMessage(rs.getString(6));
			}
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return e;
	}
	public static List<Emp3> getAllEmployees(){
		List<Emp3> list=new ArrayList<Emp3>();
		
		try{
			Connection con=EmpDao3.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from menu");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Emp3 e=new Emp3();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setEmail(rs.getString(3));
				e.setMenu(rs.getString(4));
				e.setNo(rs.getString(5));
				e.setMessage(rs.getString(6));
				list.add(e);
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
}
