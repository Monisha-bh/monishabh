

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/ViewServlet2")
public class ViewServlet2 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='index5.html'>Add New Employee</a>");
		out.println("<h1>Employees List</h1>");
		
		List<Emp2> list=EmpDao2.getAllEmployees();
		
		out.print("<table border='1' width='100%'");
		
		out.print("<tr><th>Name</th><th>Email</th><th>Doj</th><th>Room</th><th>No</th><th>Message</th><th>Edit</th><th>Delete</th></tr>");
		for(Emp2 e:list){
			out.print("<tr><td>"+e.getName()+"</td><td>"+e.getEmail()+"</td><td>"+e.getDoj()+"</td><td>"+e.getRoom()+"</td><td>"+e.getNo()+"</td><td>"+e.getMessage()+"</td><td><a href='EditServlet21?name="+e.getName()+"'>edit</a></td><td><a href='DeleteServlet2?name="+e.getName()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}
