import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/SaveServlet4")
public class SaveServlet4 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String doj=request.getParameter("doj");
		String card=request.getParameter("card");
		String no=request.getParameter("no");
		String message=request.getParameter("message");
		
		Emp4 e=new Emp4();
		e.setName(name);
		e.setEmail(email);
		e.setDoj(doj);
		e.setCard(card);
		e.setNo(no);
		e.setMessage(message);
		
		int status=EmpDao4.save(e);
		if(status>0){
			out.print("<p>Record saved successfully!</p>");
			request.getRequestDispatcher("index4.html").include(request, response);
		}else{
			out.println("Sorry! unable to save record");
		}
		
		out.close();
	}

}
