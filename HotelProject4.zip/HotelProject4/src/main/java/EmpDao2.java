import java.util.*;
import java.sql.*;

public class EmpDao2 {

 public static Connection getConnection(){
  Connection con=null;
  try{
   Class.forName("oracle.jdbc.driver.OracleDriver");
   con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
  }catch(Exception e){System.out.println(e);}
  return con;
 }
 public static int save(Emp2 e){
  int status=0;
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps=con.prepareStatement("insert into room(name,email,doj,room,no,message) values (?,?,?,?,?,?)");
   ps.setString(1,e.getName());
   ps.setString(2,e.getEmail());
   ps.setString(3,e.getDoj());
   ps.setString(4,e.getRoom());
   ps.setString(5,e.getNo());
   ps.setString(6,e.getMessage());
   
   status=ps.executeUpdate();
   
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return status;
 }
 public static int update(Emp2 e){
  int status=0;
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps2=con.prepareStatement("update room set email=?,doj=?,room=?,no=?,message=? where name=?");
   ps2.setString(6,e.getName());
   ps2.setString(1,e.getEmail());
   ps2.setString(2,e.getDoj());
   ps2.setString(3,e.getRoom());
   ps2.setString(4,e.getNo());
   ps2.setString(5,e.getMessage());
   
   status=ps2.executeUpdate();
   
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return status;
 }
 public static int delete(String name){
  int status=0;
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps1=con.prepareStatement("delete from room where name=?");
   ps1.setString(1,name);
   status=ps1.executeUpdate();
   
   con.close();
  }catch(Exception e){e.printStackTrace();}
  
  return status;
 }
 public static Emp2 getEmployeeByName(String name){
  Emp2 e=new Emp2();
  
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps=con.prepareStatement("select * from room where name=?");
   ps.setString(1,name);
   ResultSet rs=ps.executeQuery();
   if(rs.next()){
    
    e.setName(rs.getString(1));
    e.setEmail(rs.getString(2));
    e.setDoj(rs.getString(3));
    e.setRoom(rs.getString(4));
    e.setNo(rs.getString(5));
    e.setMessage(rs.getString(6));
    
   
   }
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return e;
 }
 public static List<Emp2> getAllEmployees(){
  List<Emp2> list=new ArrayList<Emp2>();
  
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps=con.prepareStatement("select * from room");
   ResultSet rs=ps.executeQuery();
   while(rs.next()){
    Emp2 e=new Emp2();
    e.setName(rs.getString(1));
    e.setEmail(rs.getString(2));
    e.setDoj(rs.getString(3));
    e.setRoom(rs.getString(4));
    e.setNo(rs.getString(5));
    e.setMessage(rs.getString(6));
   
    list.add(e);
   }
   con.close();
  }catch(Exception e){e.printStackTrace();}
  
  return list;
 }
}

