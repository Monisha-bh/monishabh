

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/ViewServlet8")
public class ViewServlet8 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='index8.html'>Add New Employee</a>");
		out.println("<h1>Employees List</h1>");
		
		List<Emp8> list=EmpDao8.getAllEmployees();
		
		out.print("<table border='1' width='100%'");
		
		out.print("<tr><th>Name</th><th>Email</th><th>Address</th><th>Feedback</th><th>Message</th><th>Edit</th><th>Delete</th></tr>");
		for(Emp8 e:list){
			out.print("<tr><td>"+e.getName()+"</td><td>"+e.getEmail()+"</td><td>"+e.getAddress()+"</td><td>"+e.getFeedback()+"</td><td>"+e.getMessage()+"</td><td><a href='EditServlet8?name="+e.getName()+"'>edit</a></td><td><a href='DeleteServlet8?name="+e.getName()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}
