
public class FirstStatic 
{
static String empname="moni";
static void display()
{
	System.out.println("this is a static method");
}
public static void main(String[] args) {
	System.out.println(empname);
	display();
	System.out.println(FirstStatic.empname);
	FirstStatic.display();
}
}
