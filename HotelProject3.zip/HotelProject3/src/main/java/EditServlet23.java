import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/EditServlet23")
public class EditServlet23 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String menu=request.getParameter("menu");
		String no=request.getParameter("no");
		String message=request.getParameter("message");
		Emp3 e=new Emp3();
		e.setId(id);
		e.setName(name);
		e.setEmail(email);
		e.setMenu(menu);
		e.setNo(no);
		e.setMessage(message);
		int status=EmpDao3.update(e);
		if(status>0){
			response.sendRedirect("ViewServlet3");
		}else{
			out.println("Sorry! unable to update record");
		}
		
		out.close();
	}

}
