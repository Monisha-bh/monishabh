import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/ViewServlet4")
public class ViewServlet4 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='index4.html'>Add New Employee</a>");
		out.println("<h1>Employees List</h1>");
		
		List<Emp4> list=EmpDao4.getAllEmployees();
		
		out.print("<table border='1' width='100%'");
		
		out.print("<tr><th>Id</th><th>Name</th><th>Email</th><th>Doj</th><th>Card</th><th>No</th><th>Message</th><th>Edit</th><th>Delete</th></tr>");
		
		for(Emp4 e:list){
			out.print("<tr><td>"+e.getId()+"</td><td>"+e.getName()+"</td><td>"+e.getEmail()+"</td><td>"+e.getDoj()+"</td><td>"+e.getCard()+"</td><td>"+e.getNo()+"</td><td>"+e.getMessage()+"</td><td><a href='EditServlet4?id="+e.getId()+"'>edit</a></td><td><a href='DeleteServlet4?id="+e.getId()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}
