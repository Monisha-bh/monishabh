import java.util.*;
import java.sql.*;

public class EmpDao8 {

 public static Connection getConnection(){
  Connection con=null;
  try{
   Class.forName("oracle.jdbc.driver.OracleDriver");
   con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
  }catch(Exception e){System.out.println(e);}
  return con;
 }
 public static int save(Emp8 e){
  int status=0;
  try{
   Connection con=EmpDao8.getConnection();
   PreparedStatement ps=con.prepareStatement("insert into feed(name,email,address,feedback,message) values (?,?,?,?,?)");
   ps.setString(1,e.getName());
   ps.setString(2,e.getEmail());
   ps.setString(3,e.getAddress());
   ps.setString(4,e.getFeedback());
   ps.setString(5,e.getMessage());
   
   status=ps.executeUpdate();
   
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return status;
 }
 public static int update(Emp8 e){
  int status=0;
  try{
   Connection con=EmpDao8.getConnection();
   PreparedStatement ps2=con.prepareStatement("update feed set email=?,address=?,feedback=?,message=? where name=?");
   ps2.setString(1,e.getEmail());
   ps2.setString(2,e.getAddress());
   ps2.setString(3,e.getFeedback());
   ps2.setString(4,e.getMessage());
   ps2.setString(5,e.getName());
   
   
   status=ps2.executeUpdate();
   
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return status;
 }
 public static int delete(String name){
  int status=0;
  try{
   Connection con=EmpDao8.getConnection();
   PreparedStatement ps1=con.prepareStatement("delete from feed where name=?");
   ps1.setString(1,name);
   status=ps1.executeUpdate();
   
   con.close();
  }catch(Exception e){e.printStackTrace();}
  
  return status;
 }
 public static Emp8 getEmployeeByName(String name){
  Emp8 e=new Emp8();
  
  try{
   Connection con=EmpDao8.getConnection();
   PreparedStatement ps=con.prepareStatement("select * from feed where name=?");
   ps.setString(1,name);
   ResultSet rs=ps.executeQuery();
   if(rs.next()){
    
    e.setName(rs.getString(1));
    e.setEmail(rs.getString(2));
    e.setAddress(rs.getString(3));
    e.setFeedback(rs.getString(4));
    e.setMessage(rs.getString(5));
    
   
   }
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return e;
 }
 public static List<Emp8> getAllEmployees(){
  List<Emp8> list=new ArrayList<Emp8>();
  
  try{
   Connection con=EmpDao8.getConnection();
   PreparedStatement ps=con.prepareStatement("select * from feed");
   ResultSet rs=ps.executeQuery();
   while(rs.next()){
    Emp8 e=new Emp8();
    e.setName(rs.getString(1));
    e.setEmail(rs.getString(2));
    e.setAddress(rs.getString(3));
    e.setFeedback(rs.getString(4));
    e.setMessage(rs.getString(5));
   
    list.add(e);
   }
   con.close();
  }catch(Exception e){e.printStackTrace();}
  
  return list;
 }
}

