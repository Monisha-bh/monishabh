import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/EditServlet32")
public class EditServlet32 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String doj=request.getParameter("doj");
		String room=request.getParameter("room");
		String no=request.getParameter("no");
		String message=request.getParameter("message");
		
		
		
		Emp2 e=new Emp2();
		
		e.setName(name);
		e.setEmail(email);
		e.setDoj(doj);
		e.setRoom(room);
		e.setNo(no);
		e.setMessage(message);
		
	
		
		int status=EmpDao2.update(e);
		if(status>0){
			response.sendRedirect("ViewServlet2");
		}else{
			out.println("Sorry! unable to update record");
		}
		
		out.close();
	}

}


