public class Emp2 {

private String name,email,doj,room,no,message;


public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getDoj() {
	return doj;
}
public void setDoj(String doj) {
	this.doj = doj;
}
public String getRoom() {
	return room;
}
public void setRoom(String room) {
	this.room = room;
}
public String getNo() {
	return no;
}
public void setNo(String no) {
	this.no = no;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}

}
