import java.util.*;
import java.sql.*;

public class EmpDao6 {

 public static Connection getConnection(){
  Connection con=null;
  try{
   Class.forName("oracle.jdbc.driver.OracleDriver");
   con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
  }catch(Exception e){System.out.println(e);}
  return con;
 }
 public static int save(Emp6 e){
  int status=0;
  try{
   Connection con=EmpDao6.getConnection();
   PreparedStatement ps=con.prepareStatement("insert into contact(name,email,address,no,message) values (?,?,?,?,?)");
   ps.setString(1,e.getName());
   ps.setString(2,e.getEmail());
   ps.setString(3,e.getAddress());
   ps.setString(4,e.getNo());
   ps.setString(5,e.getMessage());
   
   status=ps.executeUpdate();
   
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return status;
 }
 public static int update(Emp6 e){
  int status=0;
  try{
   Connection con=EmpDao6.getConnection();
   PreparedStatement ps2=con.prepareStatement("update contact set email=?,address=?,no=?,message=? where name=?");
   ps2.setString(1,e.getEmail());
   ps2.setString(2,e.getAddress());
   ps2.setString(3,e.getNo());
   ps2.setString(4,e.getMessage());
   ps2.setString(5,e.getName());
   
   
   status=ps2.executeUpdate();
   
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return status;
 }
 public static int delete(String name){
  int status=0;
  try{
   Connection con=EmpDao6.getConnection();
   PreparedStatement ps1=con.prepareStatement("delete from contact where name=?");
   ps1.setString(1,name);
   status=ps1.executeUpdate();
   
   con.close();
  }catch(Exception e){e.printStackTrace();}
  
  return status;
 }
 public static Emp6 getEmployeeByName(String name){
  Emp6 e=new Emp6();
  
  try{
   Connection con=EmpDao6.getConnection();
   PreparedStatement ps=con.prepareStatement("select * from contact where name=?");
   ps.setString(1,name);
   ResultSet rs=ps.executeQuery();
   if(rs.next()){
    
    e.setName(rs.getString(1));
    e.setEmail(rs.getString(2));
    e.setAddress(rs.getString(3));
    e.setNo(rs.getString(4));
    e.setMessage(rs.getString(5));
    
   
   }
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return e;
 }
 public static List<Emp6> getAllEmployees(){
  List<Emp6> list=new ArrayList<Emp6>();
  
  try{
   Connection con=EmpDao6.getConnection();
   PreparedStatement ps=con.prepareStatement("select * from contact");
   ResultSet rs=ps.executeQuery();
   while(rs.next()){
    Emp6 e=new Emp6();
    e.setName(rs.getString(1));
    e.setEmail(rs.getString(2));
    e.setAddress(rs.getString(3));
    e.setNo(rs.getString(4));
    e.setMessage(rs.getString(5));
   
    list.add(e);
   }
   con.close();
  }catch(Exception e){e.printStackTrace();}
  
  return list;
 }
}

