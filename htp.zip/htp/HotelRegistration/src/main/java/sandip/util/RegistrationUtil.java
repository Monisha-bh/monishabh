package sandip.util;

import org.springframework.stereotype.Component;

import sandip.model.Registration;

@Component
public class RegistrationUtil {

	public void mapToActualObject(Registration actual, Registration registration) {
		if(registration.getName()!=null)
			actual.setName(registration.getName());
		actual.setPassword(registration.getPassword());
		actual.setMessage(registration.getMessage());
		if(registration.getEmail()!=null)
			actual.setEmail(registration.getEmail());
		actual.setAddress(registration.getAddress());
	}

}
