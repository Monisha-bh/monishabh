package sandip.service;

import java.util.List;
import java.util.Optional;

import sandip.model.Registration;

public interface IRegistrationService {

	Integer saveRegistration(Registration s);
	void updateRegisration(Registration s);
	
	void deleteRegistration(Integer id);

	Optional<Registration> getOneRegistration(Integer id);
	List<Registration> getAllRegistration();

	boolean isRegistrationExist(Integer id);
}
