package sandip.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sandip.model.Registration;
import sandip.repo.RegistrationRepository;
import sandip.service.IRegistrationService;

@Service
public class RegistrationServiceImpl implements IRegistrationService {

	@Autowired
	private RegistrationRepository repo;
	
	@Override
	public Integer saveRegistration(Registration s) {
		s = repo.save(s);
		return s.getId();
	}

	public void updateRegistration(Registration s) {
		repo.save(s);
	}

	@Override
	public void deleteRegistration(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<Registration> getOneRegistration(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Registration> getAllRegistration() {
		return repo.findAll();
	}

	@Override
	public boolean isRegistrationExist(Integer id) {
		return repo.existsById(id);
	}

	@Override
	public void updateRegisration(Registration s) {
		// TODO Auto-generated method stub
	repo.save(s);
		
	}

}
